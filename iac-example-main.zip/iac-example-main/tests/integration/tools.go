// +build tools

package tools

import _ "github.com/onsi/ginkgo/ginkgo"
